// Exercise 22: Tree View
// Complete the TODOs below

// TODO 1: Define your state object
const state = {
    // Add your state properties here
};

// TODO 2: Create updateState function
function updateState(changes) {
    // Your code here
}

// TODO 3: Create render function
function render() {
    // Your code here
}

// TODO 4: Add your event listeners and logic
// Your code here

// TODO 5: Initial render
// render();
